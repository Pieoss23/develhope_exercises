Modificare il codice dell'esercizio 3 utilizzando il parent selector '&' per le classi annidate.
Stilizzare l'h2 che avrà le stesse regole di h1 con in più in padding di 1rem e un borso rosso.
Per stilizzare l'h1 e l'h2 utilizare il metodo extend.

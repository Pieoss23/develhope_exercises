Ricreare il layout fornito utilizzando il nesting delle regole e le variabili SASS.
I colori da utilizzare sono:
- red
- blue
- green
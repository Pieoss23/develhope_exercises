Modificare il codice dell'esercizio 2 creando un modulo per tutte le variabili dichiarate.
Creare poi un modulo con una funzione che trasformi i px in rem, quindi che accetti come parametro un numero e restituisca il valore relativo in rem.
Consideriamo che 1rem = 16px.
Tale funzione dovrà essere applicata nel foglio principale in modo che l'unica unità di misura sia il rem.



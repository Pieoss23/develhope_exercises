Ricreare il layout fornito utilizzando un mixin tale da poter applicare lo stile necessario a tutti i tag article.
Tale mixin dovrà accettare come parametri il color, il border-color e il font-size. Il font-size dovrà anche avere un valore di default pari a 1rem.
Il font-size del footer è pari a 24px.
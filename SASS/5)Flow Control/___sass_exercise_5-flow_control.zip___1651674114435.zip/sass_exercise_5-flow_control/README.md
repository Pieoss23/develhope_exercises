Aggiungere una nuova sezione al layout come mostrato nell' immagine allegata.
I box sono quadrati di 45px (da trasformare in rem) per lato e il loro allineamento è eseguito con flex.
Il background-color, il color e il font-size dovranno essere gestiti utilizzando il flow control (@for, @if, ecc...) e i metodi darken e lighten (l'amount ha un moltiplicatore pari a 5).
In particolare bisogna creare le classi .fs-1rem, .fs-2rem e .fs-3rem utilizzando @each.
I colori aggiunti sono solo white e black.

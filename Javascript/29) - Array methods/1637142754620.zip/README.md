# Array Methods - Exercise 1
Implementare la funzione `adultFilter` che, dato un array di persone, filtra e restituisce soltanto coloro che sono maggiorenni.
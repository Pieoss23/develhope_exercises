# Conditionals & Loops - Exercise 5
Implementare, tramite blocchi condizionali e cicli, la funzione `calculateAverageAge`, la quale, dato un array di persone, calcola l'età media
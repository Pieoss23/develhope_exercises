# Classes - Exercise 5

Definire la classe `BankAccountVip` che estendendo dalla classe `BankAccount`, oltre a consentire tutte le operazioni di quest'ultima, permette all'utente di ottenere un interesse del 3% sull'importo depositato, ma solo se quest'ultimo è maggiore o uguale a 1000€. Il risultato finale deve essere 5541.

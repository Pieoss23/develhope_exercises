# Array Methods - Exercise 5
Implementare la funzione `firstUncompletedNote` che, dato un array di note, restituisce la prima nota non completata.
Una nota viene considerata completata se **tutti** i todo presenti hanno il flag `done` impostato a `true`.
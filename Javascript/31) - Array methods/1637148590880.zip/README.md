# Array Methods - Exercise 3
Implementare la funzione `ageAverage` che, dato un array di persone, calcola l'età media.
# Arrow functions - Exercise 1
Trasformare le due variabili funzione (`sum` e `log`) in due arrow functions
# Object Methods - Exercise 1
Utilizzando l'oggetto `person` stampare in console i suoi valori nel seguente modo utilizzando il metodo `Object.keys`:

```
firstName: Mario
lastName: Rossi
age: 25
```
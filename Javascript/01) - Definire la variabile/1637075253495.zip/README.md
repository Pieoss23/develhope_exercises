# Variables Declarations - Exercise 1
In questo esercizio si sta cercando di far stampare la frase "Paul plays football", ma se si esegue il codice si noterà l'errore "**personName is not defined**".

Cosa occorre fare per fixare l'errore?
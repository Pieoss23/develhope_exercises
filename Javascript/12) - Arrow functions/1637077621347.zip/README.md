# Arrow functions - Exercise 2
Trasformare la variabile funzione `concat` in una arrow function
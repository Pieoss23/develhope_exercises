# Conditionals & Loops - Exercise 7
Implementare, tramite blocchi condizionali e cicli, la funzione `sumUntil`, la quale, dato in input un valore, effettua la somma di tutti i numeri che vanno da `1` fino al valore passato come parametro

Esempio:
```
function sumUntil(maxValue) {
  // ...
}

console.log(sumUntil(5)); // OUTPUT: 1 + 2 + 3 + 4 + 5 = 15
```